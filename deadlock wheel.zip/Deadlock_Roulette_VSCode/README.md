# Deadlock Roulette by kro

A standalone HTML5 Deadlock hero roulette with 44 heroes and selectable hero pools. No build tools or dependencies required.

## Open in VS Code

1. Extract the ZIP file.
2. In **Visual Studio Code**, select **File > Open Folder**.
3. Choose the extracted `Deadlock_Roulette_VSCode` folder.
4. Double-click **index.html** in your file manager to launch it in a browser. Alternatively, use the VS Code **Live Server** extension and click **Go Live**.

## Edit the project

- `index.html` — page structure, buttons, labels, and panels.
- `css/styles.css` — colors, fonts, sizing, layout, and wheel container styling.
- `js/app.js` — hero roster and groups, selection logic, canvas drawing, spin animations, sounds, and event handlers.

To add or remove a hero, edit the `groups` object at the top of `js/app.js`. To modify the gold theme, edit the `:root` variables in `css/styles.css`.

## Features

- Click the wheel, click **Spin the wheel**, or press **Space** to spin.
- **Carry**, **Tank**, **Support**, **Assassin**, and **New Heroes** tabs.
- Search, include/exclude heroes, instant pick, winner elimination, sound toggle, and history.
- Runs completely offline.

This is an unofficial fan project.
